int divide(int a, int b) 
{
    return a / b;
}

