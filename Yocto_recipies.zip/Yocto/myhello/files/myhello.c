#include<stdio.h>
#include<mylib.h>

int main()

{
	print("Hello world \n",7);
	return 0;
}

