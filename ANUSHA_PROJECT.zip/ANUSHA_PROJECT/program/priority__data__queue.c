/*-------------------------***PROJECT***----------------//
NAME:ANUSHA KUNDETI,

*/
//---------------------------PRIORITY QUEUE-----------------------//


#include<stdio.h>
#include<stdlib.h>
#include<stdio_ext.h>
//--------------------------STRUCTURE DEFINITION-----------------//
struct node
{
	struct node *prev;
	int data;
	int priority;
	struct node *next;
};

//------------------------GLOBAL VARIABLE----------------------//
struct node *head=NULL;
//--------------------
void insert(int, int);

void display_priority(int);
void display_overall();

void delete_overall();
void delete_priority(int);
void delete_priority_data(int , int);
void delete_first_priority(int);

void create_queue(int*, int*, int);
void sort_overall_data();
void sort_overall_links();




void main()
{

	int opt, num, pri, i, n, data;
	char sub_opt;
	int *ptr1, *ptr2;


	while(1)
	{
		printf("---------------------------------------------------------------------\n");
		printf("Menu\n0.exit\n1.Insert\n2.Display\n3.Delete\n4.Create Queue\n5.sort data\n"); 
		printf("Enter the option\n");
		scanf("%d", &opt);
		switch(opt)
		{
			case 0:exit(0);
			case 1:printf("Enter data and priority\n ");
			       scanf("%d %d", &num,&pri);
			       insert(num, pri);
			       break;
			case 2:printf("Menu\n a. Overall Display\n b.Display Priority\n");
			       __fpurge(stdin);
			       scanf("%c", &sub_opt);
			       switch(sub_opt)
			       {
				       case 'a':display_overall();
						break;
				       case 'b':printf("Enter the priority: ");
						__fpurge(stdin);
						scanf("%d", &num);
						display_priority(num);
						break;
			       }
			       break;
			case 3:printf("Menu\na.Delete Overall\nb.Delete Priority\nc.Delete Priority Data\nd.Delete First Priority\n");
			       __fpurge(stdin);
			       scanf("%c", &sub_opt);
			       switch(sub_opt)
			       {
				       case 'a':delete_overall();
						break;
				       case 'b': printf("Enter the Priority No to delete :");
						__fpurge(stdin);
						 scanf("%d", &pri); 
						 delete_priority(pri);
						 break;
				       case 'c': printf("Enter the priority: ");
						 __fpurge(stdin);
						 scanf("%d", &num);
						 printf("Enter the data: ");
						 __fpurge(stdin);
						 scanf("%d", &data);
						 delete_priority_data(num,data);
						 break;
				       case 'd':printf("Enter the Priority No :");
						__fpurge(stdin);
						scanf("%d", &pri); 
						delete_first_priority(pri);
						break;
			       }
			       break;
			case 4:printf("Enter the no of nodes: ");
			       __fpurge(stdin);
			       scanf("%d", &n);
			       __fpurge(stdin);
			       ptr1=(int *)malloc(n*sizeof(int));
			       ptr2=(int *)malloc(n*sizeof(int));
			       for(i=0;i<n; i++)
			       {
				       printf("Enter the Data & Priority ");
				       scanf("%d %d", &ptr1[i], &ptr2[i]);
				       __fpurge(stdin);
			       }
			       create_queue(ptr1, ptr2, n);
			       break;
			
			       case 5:
			       printf("Menu\na.Sort overall by data\nb.sort overall by link\n");
			       __fpurge(stdin);
			       scanf("%c", &sub_opt);
			       switch(sub_opt)
			       {
				       case 'a':sort_overall_data();
						break;
				       case 'b':sort_overall_links();
						break;
			       }
			       break;
			default: printf("Enter the Correct Option");
				 break;


		}
	}

}




void insert(int num,int pri)
{
	struct node *ptr, *temp, *prv;
	ptr=(struct node *)malloc(1*sizeof(struct node));
	if(ptr==NULL)
	{
		printf("Failed to allocate Memory in heap segment");
		exit(0);
	}
	ptr->data=num;
	ptr->priority=pri;
	if(head==NULL)                                        //it contains Zero Nodes
	{
		ptr->prev=NULL;
		ptr->next=NULL;
		head=ptr;
		return;
	}
	if(head->next==NULL)                                    //it contains single node
	{
		if(pri < head->priority)                        //new node priority is less than head priority
		{
			ptr->prev = NULL;
			head->prev = ptr;
			ptr->next = head;
			head = ptr;
			return;
		}
		ptr->prev = head;                               //it contains single node and we have to add after head node
		head->next = ptr;
		ptr->next = NULL;
		return;
	}
	temp=head;
	while(temp!=NULL)                                       //we have to traverse the list until the temp reaches NULL
	{
		if((temp->priority)>(ptr->priority))            
		{


			ptr->next=temp;
			ptr->prev=temp->prev;
			temp->prev=ptr;
			if(temp == head)
				head = ptr;
			else
				ptr->prev->next = ptr;

			return;
		}
		prv=temp;
		temp=temp->next;
	}

	ptr->prev=prv;
	prv->next=ptr;
	ptr->next=NULL;
	return;


}
//	-----------------------------------------------------------------------------------------------
void display_priority(int pri)
{
	struct node *temp;
	if(head==NULL)
	{
		printf("Queue is empty");
		return;
	}
	temp=head;
	while(temp!=NULL)
	{
		if(temp->priority==pri)
		{

		//	printf("%-15p  -- %-15p  -- %-15p", temp->prev, temp, temp->next);
			printf("data-%d        priority-%d\n", temp->data, temp->priority);
		}
		temp=temp->next;
	}
	return;
}
//	----------------------------------------------------------------------------------------------
void display_overall()
{
	struct node *temp;	

	if(head==NULL)
	{
		printf("List is empty");
		return;
	}
	temp=head;
	while(temp!=NULL)
	{
	//	printf("%-15p  -- %-15p  -- %-15p", temp->prev, temp, temp->next);
		printf("data-%4d  priority-%4d\n",temp->data, temp->priority);
		temp=temp->next;
	}
}
//-----------------------------------------------------------------------------------------

void delete_overall()
{
	struct node *temp, *ptr;
	if(head==NULL)
	{
		printf("Queue is empty");
		return;
	}
	temp=head;
	while(temp!=head)
	{
		ptr=temp;
		temp=temp->next;
		free(ptr);
	}
	head=temp;
}

//------------------------------------------------------------------------------------------

void delete_priority(int prity)
{
	struct node *temp, *fake, *temp1;
	if(head==NULL)
	{
		printf("Queue is empty");
		return;
	}
	temp=head;
	if(prity<0)
	{
		printf("Enter the positive Priority starting from Zero");
		return;
	}
	while(temp!=NULL)
	{
		if(temp->priority==prity)
		{
			fake=temp;
			while(fake->priority==prity)
			{
				if(head->next==NULL)
				{
					free(head);
					head=NULL;
					return;
				}
				if(fake->prev==NULL)
				{
					temp1=fake;
					fake->next->prev=NULL;
					head=fake->next;
					free(temp1);
					fake=head;
				}
				else
				{
					temp1=fake;
					fake->prev->next=fake->next;
					fake->next->prev=fake->prev;
					free(temp1);
					fake=fake->next;

				}
				if(fake->next==NULL)
				{
					fake->prev->next=NULL;
					free(fake);
					return;
				}

			}
			return;
		}
		temp=temp->next;

	}
	printf("Priority No Not Found");

}
//----------------------------------------------------------------------------


void create_queue(int* num, int* pri , int n)
{
	struct node *ptr, *temp, *prv;
	int i;
	for(i=0; i<n; i++)
	{
		ptr=(struct node *)malloc(1*sizeof(struct node));
		if(ptr==NULL)
		{
			printf("Failed to allocate Memory in heap segment");
			exit(0);
		}
		ptr->data=num[i];
		ptr->priority=pri[i];
		if(head==NULL)
		{
			ptr->prev=NULL;
			ptr->next=NULL;
			head=ptr;
			continue;
		}
		if(head->next==NULL)
		{
			if(pri[i] < head->priority)
			{
				ptr->prev = NULL;
				head->prev = ptr;
				ptr->next = head;
				head = ptr;
				continue;
			}
			ptr->prev = head;
			head->next = ptr;
			ptr->next = NULL;
			continue;
		}
		temp=head;
		while(temp!=NULL)
		{
			if((temp->priority)>(ptr->priority))
			{


				ptr->next=temp;
				ptr->prev=temp->prev;
				temp->prev=ptr;
				if(temp == head)
					head = ptr;
				else
					ptr->prev->next = ptr;

				break;
			}
			prv=temp;
			temp=temp->next;
		}
		if(temp==NULL)
		{
			ptr->prev=prv;
			prv->next=ptr;
			ptr->next=NULL;

		}
	}
}

//----------------------------------------------------------------------------------------------

void delete_priority_data(int prity, int data)
{
	struct node *temp, *fake, *temp1;
	if(head==NULL)
	{
		printf("Queue is empty");
		return;
	}
	temp=head;
	if(prity<0)
	{
		printf("Enter the positive Priority starting from Zero");
		return;
	}
	while(temp!=NULL)
	{
		if(temp->priority==prity)
		{
			fake=temp;
			while(fake->priority==prity)
			{
				if(fake->data==data)
				{
					if(head->next==NULL)
					{
						free(head);
						head=NULL;
						return;
					}
					if(fake->prev==NULL)
					{
						temp1=fake;
						fake->next->prev=NULL;
						head=fake->next;
						free(temp1);
						fake=head;

					}
					else
					{
						temp1=fake;
						fake->prev->next=fake->next;
						fake->next->prev=fake->prev;
						free(temp1);
						fake=fake->next;

					}
					if(fake->next==NULL)
					{
						fake->prev->next=NULL;
						free(fake);
						return;
					}

				}
				return;
			}
		}
		temp=temp->next;


	}
	printf("Priority No Not Found");

}

//------------------------------------------------------------------------


void delete_first_priority(int prity)
{
	struct node *temp, *temp1;;
	if(head==NULL)
	{
		printf("Queue is empty");
		return;
	}
	temp=head;
	if(prity<0)
	{
		printf("Enter the positive Priority starting from Zero");
		return;
	}
	while(temp!=NULL)
	{
		if(temp->priority==prity)
		{
			temp1=temp->next;
			if(temp->prev!=NULL)
				
				temp->prev->next=temp->next;
			else
				head=temp->next;
			if(temp->next!=NULL)
				temp->next->prev=temp->prev;
			free(temp);
			temp=temp1;
			return;
		}



		temp=temp->next;
	}
	printf("Priority No not Found");
}


//-----------------------------------------------------------------------------------

void sort_overall_data()
{
	struct node *p, *q;
	int temp;
	for(p=head; p->next!=NULL;p=p->next)
	{
		for(q=p->next; q!=NULL; q=q->next)
		{
			if(p->priority==q->priority)
			{
				if(p->data>q->data)
				{
					temp=p->data;
					p->data=q->data;
					q->data=temp;
				}
			}
		}
	}
}

//---------------------------------------------------------------------------------------------

void sort_overall_links()
{
	struct node *p, *q,*temp;
	for(p=head; p->next!=NULL;p=p->next)
	{
		for(q=p->next; q!=NULL; q=q->next)
		{
			if(p->priority==q->priority)
			{
				if(p->data>q->data)
				{
					if(p->next!=q) //non adjacent
					{
						temp=p->next;
						p->next=q->next;
						q->next =temp;

						temp=p->prev;
						p->prev=q->prev;
						q->prev=temp;

						if(p!=head)
							q->prev->next=q;
						else
							head=q;
						p->prev->next=p;
						q->next->prev=q;
						if(p->next!=NULL)
							p->prev->prev=q;

					}
					else //adjacent
					{
						p->next=q->next;
						q->next=p;
						q->prev=p->prev;
						p->prev=q;
						if(p!=head)
							q->prev->next=q;
						else
							head=q;
						if(p->next!=NULL)
							p->next->prev=p;
					}
					temp=p;
					p=q;
					q=temp;
				}
			}
		}
	}
}































