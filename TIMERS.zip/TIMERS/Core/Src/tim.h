/*
 * tim.h
 *
 *  Created on: Jul 25, 2023
 *      Author: Anusha
 */

#include"stm32f4xx.h"

#ifndef INC_TIM_H_

#define INC_TIM_H_

#define SR_UIF (1U<<0)

void tim2_1hz_init(void);
void tim_delay(void);

#endif
