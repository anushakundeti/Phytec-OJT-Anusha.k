/*
 * time.c
 *
 *  Created on: Jul 25, 2023
 *      Author: Anusha
 */


#include"tim.h"
#define TIM2EN (1U<<0)
#define CR1_CEN (1U<<0)
 void tim2_1hz_init(void)
  {
	  RCC-> APB1ENR |=1;
	  TIM2 ->PSC =1600-1;
	  TIM2 ->ARR =10000-1;
	  TIM2 ->CNT =0;
	  TIM2 ->CR1 =CR1_CEN;


  }



  void tim_delay(void)
  {
	  while(!(TIM2 ->SR & SR_UIF)){}
	  TIM2 ->SR &=SR_UIF;
  }
