#include <stdlib.h>

//int system(const char *command);


int main()
{

	system("date");
	return 0;
}
