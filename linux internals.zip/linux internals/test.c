#include<stdio.h>


int main()
{
	char d;

	while((d = getchar())  != 'x')
		putchar(d);
	return 0;
}

